<h1>shopping app</h1>

<h3>
this project i creat an awesome  Shopping App UI and backend with flutter and firebase
</h3>
<p>
tutorial :
https://www.youtube.com/playlist?list=PLNtn1FgzEKBA2O8caXFup7qQ_gbkMxbjo
</p>
<hr>
<div style = ""> 
<img src="https://github.com/alireza4585/ecommerce1/assets/102475069/b3a289a6-9d19-4e5c-9bcb-ccd80ba8b3de" alt="Screenshot_1666104775" width="32%"/>
<img src="https://github.com/alireza4585/ecommerce1/assets/102475069/fddd1339-714a-4a26-96b9-0bf93dd4cc6e" alt="Screenshot_1659640778" width="32%"/>
<img src="https://github.com/alireza4585/ecommerce1/assets/102475069/aa54dc35-8e7f-425e-be89-3492615b39d9" alt="Screenshot_1666104775" width="32%"/>

</div>
