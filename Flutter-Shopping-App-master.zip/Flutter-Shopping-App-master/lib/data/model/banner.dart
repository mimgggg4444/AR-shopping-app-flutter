class banner {
  String? name;
  String? image;
  String? image1;
  String? image2;
  String? image3;
  String? price;
}
