import 'package:flutter/material.dart';

Color backgroundColor = Color.fromARGB(255, 238, 238, 238);
Color mains = Color(0xffF35383);
